from mysql.connector import connect
try:
    host = input("host: ")
    user = input("username: ")
    passwd = input("password: ")
    database = input("database: ")
    connection = connect(host=host, user=user, passwd=passwd, database=database)  
    cursor = connection.cursor()
    sql = "INSERT INTO Employees (id, name, salary, job_id, dept_id) \
            VALUES (%s, %s, %s, %s, %s);"
    val = (1, "Kyaw Kyaw", 50000, 10, 25)
    cursor.execute(sql, val)  
    for r in cursor:
        print(r)
except Exception as e:
    print(e)
