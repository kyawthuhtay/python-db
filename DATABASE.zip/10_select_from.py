from mysql.connector import connect
try:
    host = input("host: ")
    user = input("username: ")
    passwd = input("password: ")
    database = input("database: ")
    connection = connect(host=host, user=user, passwd=passwd, database=database)  
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Employees;")  
    result = cursor.fetchall()
    for r in result:
        print(r)
except Exception as e:
    print(e)
