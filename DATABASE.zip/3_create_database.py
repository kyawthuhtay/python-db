from mysql.connector import connect
try:
    host = input("host: ")
    user = input("username: ")
    passwd = input("password: ")
    connection = connect(host=host, user=user, passwd=passwd)  
    cursor = connection.cursor()
    cursor.execute("CREATE DATABASE FirstDB;")  
    for r in cursor:
        print(r)
except Exception as e:
    print(e)
