from mysql.connector import connect
try:
    host = input("host: ")
    user = input("username: ")
    passwd = input("password: ")
    database = input("database: ")
    connection = connect(host=host, user=user, passwd=passwd, database=database)  
    cursor = connection.cursor()
    sql = "INSERT INTO Employees (id, name, salary, job_id, dept_id) \
            VALUES (%s, %s, %s, %s, %s);"
    val = [
        (2, "Aung Aung", 40000, 11, 26),
        (3, "Mg Mg", 70000, 12, 27),
        (4, "Aye Aye", 45000, 13, 28)
    ]
    cursor.executemany(sql, val)  
    for r in cursor:
        print(r)
except Exception as e:
    print(e)
