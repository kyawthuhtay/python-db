from mysql.connector import connect
try:
    host = input("host: ")
    user = input("username: ")
    passwd = input("password: ")
    database = input("database: ")
    connection = connect(host=host, user=user, passwd=passwd, database=database)  
    cursor = connection.cursor()
    cursor.execute("UPDATE Employees SET name='Maung Maung' WHERE id=3;")  
    for r in cursor:
        print(r)
except Exception as e:
    print(e)
