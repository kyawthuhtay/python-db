from mysql.connector import connect
try:
    host = input("host: ")
    user = input("username: ")
    passwd = input("password: ")
    database = input("database: ")
    connection = connect(host=host, user=user, passwd=passwd, database=database)  
    cursor = connection.cursor()
    sql = "ALTER TABLE Employees ADD dept_id varchar(20) not null;"
    cursor.execute(sql)  
    for r in cursor:
        print(r)
except Exception as e:
    print(e)
