from mysql.connector import connect
try:
    host = input("host: ")
    user = input("username: ")
    passwd = input("password: ")
    database = input("database: ")
    connection = connect(host=host, user=user, passwd=passwd, database=database)  
    cursor = connection.cursor()
    cursor.execute("DELETE FROM Employees WHERE id=4;")  
    for r in cursor:
        print(r)
except Exception as e:
    print(e)
