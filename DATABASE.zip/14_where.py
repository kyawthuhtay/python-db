from mysql.connector import connect
try:
    host = input("host: ")
    user = input("username: ")
    passwd = input("password: ")
    database = input("database: ")
    connection = connect(host=host, user=user, passwd=passwd, database=database)  
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Employees WHERE id=1;")  
    result = cursor.fetchall()
    print("Id Name Salary Job Department")
    for r in result:
        print(r[0], r[1], r[2], r[3], r[4])
except Exception as e:
    print(e)
