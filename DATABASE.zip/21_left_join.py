from mysql.connector import connect
try:
    host = input("host: ")
    user = input("username: ")
    passwd = input("password: ")
    database = input("database: ")
    connection = connect(host=host, user=user, passwd=passwd, database=database)  
    cursor = connection.cursor()
    sql = """
            SELECT 
                e.id,
                e.name,
                e.salary,
                j.name,
                d.name
            FROM Employee as e
            LEFT JOIN Jobs as j ON e.job_id=j.id
            LEFT JOIN Departments as d ON e.dept_id=d.id;
        """
    cursor.execute(sql)  
    result = cursor.fetchall()
    print("Id Name Salary Job Department")
    for r in result:
        print(r[0], r[1], r[2], r[3], r[4])
except Exception as e:
    print(e)
